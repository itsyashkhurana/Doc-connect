import React from 'react'
import Upper from './Upper'
import Docter from './Docter'
import Service from './Service'


const Home = () => {
  return (
    <div>
      <Upper/>
      <Docter/>
      <Service/>
      
    </div>
  )
}

export default Home
