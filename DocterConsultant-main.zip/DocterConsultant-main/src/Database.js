Object.defineProperties(exports , "_esModule" , {value: true});
 exports.data = [
         {
         name : "Dr. Chachu Bajaj",
         rating : 4.7,
         expertise : 5,
         price : 1000,
         img : "image/nurseprofile image.jpg"
        },
        {
            name : "Dr. Dhrita",
            rating : 4.3,
            expertise : 4,
            price : 1500,
            img :  "image/nurse3.jpg"
           },
           {
            name : "Dr. Lydia",
            rating : 4.1,
            expertise : 4.6,
            price : 800,
            img :  "image/nurse2.jpg"
           }
    
]